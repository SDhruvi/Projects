#!/usr/bin/env python
# coding: utf-8

# In[16]:


#python program to find the factorial of a number.

num = 6
factorial = 1
#check if the number is negative, positive or zero
if num < 0:
   print("Sorry, factorial does not exist for negative numbers")
elif num == 0:
   print("The factorial of 0 is 1")
else:
   for i in range(1,num + 1):
       factorial = factorial*i
   print("The factorial of",num,"is",factorial)


# In[17]:


#python program to find whether a number is prime or composite.

num = int(input("Enter any number : "))
if num > 1:
    for i in range(2, num):
        if (num % i) == 0:
            print(num, "is NOT a prime number")
            break
    else:
        print(num, "is a PRIME number")
elif num == 0 or 1:
    print(num, "is a neither prime NOR composite number")
else:
    print(num, "is NOT a prime number it is a COMPOSITE number")


# In[18]:


#python program to check whether a given string is palindrome or not.

str = 'I am ready'

# make it suitable for caseless comparison
str = str.casefold()

# reverse the string
rev_str = reversed(str)

# check if the string is equal to its reverse
if list(str) == list(rev_str):
   print("The string is a palindrome.")
else:
   print("The string is not a palindrome.")


# In[19]:


#python program to get the third side of right-angled triangle from two given sides.

from math import sqrt

a = 5
b = 6
c = sqrt(a**2 + b**2)
print("The length of the hypotenuse is:", c )


# In[20]:


#python program to print the frequency of each of the characters present in a given string.

def char_frequency(str1):
    dict = {}
    for n in str1:
        keys = dict.keys()
        if n in keys:
            dict[n] += 1
        else:
            dict[n] = 1
    return dict
print(char_frequency('Data Science was named as sexiest job by Harvad in 2012'))


# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:




